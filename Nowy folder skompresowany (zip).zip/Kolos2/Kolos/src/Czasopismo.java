public class Czasopismo extends Publikacja{
    private int numer;

    public Czasopismo(String tytul, double cena, int rok, int miesiac, int dzien, int numer) {
        super(tytul, cena, rok, miesiac, dzien);
        this.numer = numer;
    }

    public int getNumer() {
        return numer;
    }

    public void setNumer(int numer) {
        this.numer = numer;
    }
    @Override
    public String toString(){
        return super.toString() + ",[" + this.numer + "]";
    }

    @Override
    public boolean equals(Object Otherobj) {
        if(this.getClass()!= Otherobj.getClass())
            return false;
        if(this == Otherobj)
            return true;
        Czasopismo obj = (Czasopismo) Otherobj;
        return super.equals(Otherobj) && this.numer == obj.numer;
    }
}
