import java.time.LocalDate;
import java.util.Objects;

public class Publikacja {
    private final String tytul;
    private double cena;
    private LocalDate dataWydania;
    private static int ile;

    public Publikacja(String tytul, double cena, int rok, int miesiac, int dzien) {
        this.tytul = tytul;
        this.cena = cena;
        this.dataWydania = LocalDate.of(rok,miesiac,dzien);
        ile++;
    }
    public Publikacja(String tytul, double cena) {
        this.tytul = tytul;
        this.cena = cena;
        this.dataWydania = LocalDate.now();
        ile++;
    }

    public String getTytul() {
        return tytul;
    }

    public double getCena() {
        return cena;
    }

    public LocalDate getDataWydania() {
        return dataWydania;
    }

    public void setDataWydania(int rok, int miesiac, int dzien) {
        this.dataWydania = LocalDate.of(rok,miesiac,dzien);
    }
    @Override
    public String toString(){
        StringBuilder text = new StringBuilder();
        text.append(this.getClass().getName());
        text.append("[").append(this.dataWydania).append("],");
        if(!Objects.equals(this.tytul, "Publikacja Nieznana"))
            text.append("[").append(this.tytul).append("],");
        text.append("[").append(this.cena).append("]");
        return text.toString();
    }

    @Override
    public boolean equals(Object Otherobj) {
        if(this.getClass()!= Otherobj.getClass())
            return false;
        if(this == Otherobj)
            return true;
        Publikacja obj = (Publikacja) Otherobj;
        return Objects.equals(this.tytul, obj.tytul) && this.cena == obj.cena &&
                this.dataWydania.getYear() == obj.dataWydania.getYear() &&
                this.dataWydania.getMonth() == obj.dataWydania.getMonth() &&
                this.dataWydania.getDayOfMonth() == obj.dataWydania.getDayOfMonth();
    }
    public void zwiekszCene(double procent){
        this.cena = this.cena + this.cena * procent/100;
    }
    public static int getIle() {
        return ile;
    }

}